// ============================================
// src/types/index.ts
// Core type definitions for Revenue Clarity
// ============================================

export interface BusinessInput {
  // Revenue
  monthlyRevenue: number
  annualRevenue?: number
  recurringRevenue?: number

  // Costs
  costOfGoodsSold: number
  operatingExpenses: number
  monthlyBurnRate?: number

  // Customers
  totalCustomers: number
  newCustomersPerMonth: number
  lostCustomersPerMonth: number
  avgCustomerLifespanMonths: number

  // Acquisition
  totalMarketingSpend: number
  totalSalesSpend: number

  // Pricing
  avgRevenuePerCustomer: number
  avgTransactionValue?: number
  transactionsPerCustomerPerMonth?: number
}

export interface RevenueMetrics {
  mrr: number
  arr: number
  grossProfit: number
  grossMarginPercent: number
  netProfit: number
  netMarginPercent: number
  burnRate: number
  runwayMonths: number | null
}

export interface CustomerMetrics {
  cac: number
  ltv: number
  ltvCacRatio: number
  churnRate: number
  retentionRate: number
  avgRevenuePerUser: number
  paybackPeriodMonths: number
}

export interface GrowthMetrics {
  mrrGrowthRate: number
  customerGrowthRate: number
  revenuePerEmployee?: number
  netRevenueRetention?: number
}

export interface BreakEvenAnalysis {
  breakEvenRevenue: number
  breakEvenUnits: number
  marginOfSafety: number
  contributionMargin: number
  contributionMarginRatio: number
}

export interface FullReport {
  input: BusinessInput
  revenue: RevenueMetrics
  customer: CustomerMetrics
  breakEven: BreakEvenAnalysis
  healthScore: HealthScore
  generatedAt: string
}

export interface HealthScore {
  score: number           // 0–100
  grade: 'A' | 'B' | 'C' | 'D' | 'F'
  summary: string
  flags: HealthFlag[]
}

export interface HealthFlag {
  type: 'warning' | 'danger' | 'good'
  metric: string
  message: string
}

export interface MetricExplanation {
  name: string
  value: number
  formatted: string
  unit: string
  explanation: string
  benchmark?: string
  status: 'good' | 'warning' | 'danger' | 'neutral'
}
