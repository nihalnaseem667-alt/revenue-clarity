// ============================================
// src/main.ts
// Application entry point
// ============================================

import { generateReport } from '@/calculators'
import { formatCurrency, formatPercent, formatRatio, formatMonths, formatShort } from '@/utils/format'

// ── Example usage ─────────────────────────────────────
const exampleInput = {
  // Revenue
  monthlyRevenue: 500_000,
  recurringRevenue: 420_000,

  // Costs
  costOfGoodsSold: 150_000,
  operatingExpenses: 200_000,
  monthlyBurnRate: 350_000,

  // Customers
  totalCustomers: 200,
  newCustomersPerMonth: 30,
  lostCustomersPerMonth: 8,
  avgCustomerLifespanMonths: 24,

  // Acquisition
  totalMarketingSpend: 80_000,
  totalSalesSpend: 40_000,

  // Pricing
  avgRevenuePerCustomer: 2_500,
}

const cashOnHand = 2_000_000

try {
  const report = generateReport(exampleInput, cashOnHand)

  console.log('\n╔══════════════════════════════════════╗')
  console.log('║        REVENUE CLARITY REPORT        ║')
  console.log('╚══════════════════════════════════════╝\n')

  console.log('── REVENUE ─────────────────────────────')
  console.log(`  MRR              ${formatShort(report.revenue.mrr)}`)
  console.log(`  ARR              ${formatShort(report.revenue.arr)}`)
  console.log(`  Gross Profit     ${formatShort(report.revenue.grossProfit)}`)
  console.log(`  Gross Margin     ${formatPercent(report.revenue.grossMarginPercent)}`)
  console.log(`  Net Profit       ${formatShort(report.revenue.netProfit)}`)
  console.log(`  Net Margin       ${formatPercent(report.revenue.netMarginPercent)}`)
  console.log(`  Burn Rate        ${formatShort(report.revenue.burnRate)}/mo`)
  console.log(`  Runway           ${report.revenue.runwayMonths ? formatMonths(report.revenue.runwayMonths) : 'N/A'}`)

  console.log('\n── CUSTOMERS ───────────────────────────')
  console.log(`  CAC              ${formatCurrency(report.customer.cac)}`)
  console.log(`  LTV              ${formatCurrency(report.customer.ltv)}`)
  console.log(`  LTV:CAC          ${formatRatio(report.customer.ltvCacRatio)}`)
  console.log(`  Churn Rate       ${formatPercent(report.customer.churnRate)}/mo`)
  console.log(`  Retention        ${formatPercent(report.customer.retentionRate)}`)
  console.log(`  Payback Period   ${formatMonths(report.customer.paybackPeriodMonths)}`)

  console.log('\n── BREAK-EVEN ──────────────────────────')
  console.log(`  Break-even Rev   ${formatShort(report.breakEven.breakEvenRevenue)}/mo`)
  console.log(`  Break-even Units ${report.breakEven.breakEvenUnits} customers`)
  console.log(`  Margin of Safety ${formatPercent(report.breakEven.marginOfSafety)}`)
  console.log(`  Contribution Mar ${formatPercent(report.breakEven.contributionMarginRatio)}`)

  console.log('\n── HEALTH SCORE ────────────────────────')
  console.log(`  Score   ${report.healthScore.score}/100  (Grade: ${report.healthScore.grade})`)
  console.log(`  ${report.healthScore.summary}`)
  console.log('\n  Flags:')
  for (const flag of report.healthScore.flags) {
    const icon = flag.type === 'good' ? '✓' : flag.type === 'warning' ? '⚠' : '✗'
    console.log(`  ${icon}  ${flag.message}`)
  }

  console.log('\n────────────────────────────────────────')
  console.log(`  Generated: ${new Date(report.generatedAt).toLocaleString()}\n`)

} catch (err) {
  console.error('Report generation failed:', err)
}
