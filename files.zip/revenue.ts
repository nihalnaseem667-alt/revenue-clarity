// ============================================
// src/calculators/revenue.ts
// Core revenue metric calculations
// ============================================

import type { BusinessInput, RevenueMetrics } from '@/types'
import { round } from '@/utils/format'

/**
 * Monthly Recurring Revenue
 * The predictable revenue generated every month
 */
export function calculateMRR(input: Pick<BusinessInput, 'recurringRevenue' | 'monthlyRevenue'>): number {
  return round(input.recurringRevenue ?? input.monthlyRevenue)
}

/**
 * Annual Recurring Revenue
 * MRR × 12 — the yearly view of recurring revenue
 */
export function calculateARR(mrr: number): number {
  return round(mrr * 12)
}

/**
 * Gross Profit
 * Revenue after subtracting direct production costs
 */
export function calculateGrossProfit(revenue: number, cogs: number): number {
  return round(revenue - cogs)
}

/**
 * Gross Margin %
 * What percentage of revenue is actual profit before operating expenses
 * Benchmark: >60% is strong for SaaS, >30% for physical products
 */
export function calculateGrossMargin(revenue: number, cogs: number): number {
  if (revenue === 0) return 0
  return round(((revenue - cogs) / revenue) * 100)
}

/**
 * Net Profit
 * What's left after ALL expenses — the real bottom line
 */
export function calculateNetProfit(revenue: number, cogs: number, opex: number): number {
  return round(revenue - cogs - opex)
}

/**
 * Net Profit Margin %
 * Benchmark: >10% is healthy, >20% is excellent
 */
export function calculateNetMargin(revenue: number, netProfit: number): number {
  if (revenue === 0) return 0
  return round((netProfit / revenue) * 100)
}

/**
 * Burn Rate
 * How much cash the business spends per month
 */
export function calculateBurnRate(input: Pick<BusinessInput, 'monthlyBurnRate' | 'costOfGoodsSold' | 'operatingExpenses'>): number {
  return round(input.monthlyBurnRate ?? (input.costOfGoodsSold + input.operatingExpenses))
}

/**
 * Runway (months)
 * How many months until cash runs out — requires cash on hand
 */
export function calculateRunway(cashOnHand: number | null, burnRate: number): number | null {
  if (!cashOnHand || burnRate === 0) return null
  return round(cashOnHand / burnRate)
}

/**
 * Full Revenue Metrics — runs all calculations in one call
 */
export function calculateRevenueMetrics(input: BusinessInput, cashOnHand?: number): RevenueMetrics {
  const mrr = calculateMRR(input)
  const arr = calculateARR(mrr)
  const grossProfit = calculateGrossProfit(input.monthlyRevenue, input.costOfGoodsSold)
  const grossMarginPercent = calculateGrossMargin(input.monthlyRevenue, input.costOfGoodsSold)
  const netProfit = calculateNetProfit(input.monthlyRevenue, input.costOfGoodsSold, input.operatingExpenses)
  const netMarginPercent = calculateNetMargin(input.monthlyRevenue, netProfit)
  const burnRate = calculateBurnRate(input)
  const runwayMonths = calculateRunway(cashOnHand ?? null, burnRate)

  return {
    mrr,
    arr,
    grossProfit,
    grossMarginPercent,
    netProfit,
    netMarginPercent,
    burnRate,
    runwayMonths,
  }
}
