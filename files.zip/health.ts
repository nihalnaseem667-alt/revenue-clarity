// ============================================
// src/calculators/health.ts
// Business health scoring engine
// ============================================

import type { RevenueMetrics, CustomerMetrics, BreakEvenAnalysis, HealthScore, HealthFlag } from '@/types'

/**
 * Score a business across key metrics and return a grade
 * Score breakdown:
 *   Gross Margin      → 25 pts
 *   LTV:CAC Ratio     → 25 pts
 *   Churn Rate        → 20 pts
 *   Net Margin        → 20 pts
 *   Margin of Safety  → 10 pts
 */
export function calculateHealthScore(
  revenue: RevenueMetrics,
  customer: CustomerMetrics,
  breakEven: BreakEvenAnalysis
): HealthScore {
  let score = 0
  const flags: HealthFlag[] = []

  // ── Gross Margin (25 pts) ──────────────────────────
  if (revenue.grossMarginPercent >= 60) {
    score += 25
    flags.push({ type: 'good', metric: 'Gross Margin', message: `${revenue.grossMarginPercent.toFixed(1)}% gross margin — excellent.` })
  } else if (revenue.grossMarginPercent >= 30) {
    score += 15
    flags.push({ type: 'warning', metric: 'Gross Margin', message: `${revenue.grossMarginPercent.toFixed(1)}% gross margin — room to improve. Aim for 60%+.` })
  } else {
    score += 5
    flags.push({ type: 'danger', metric: 'Gross Margin', message: `${revenue.grossMarginPercent.toFixed(1)}% gross margin — critically low. Review your COGS immediately.` })
  }

  // ── LTV:CAC Ratio (25 pts) ─────────────────────────
  if (customer.ltvCacRatio >= 3) {
    score += 25
    flags.push({ type: 'good', metric: 'LTV:CAC', message: `${customer.ltvCacRatio.toFixed(2)}x LTV:CAC — healthy acquisition economics.` })
  } else if (customer.ltvCacRatio >= 1.5) {
    score += 12
    flags.push({ type: 'warning', metric: 'LTV:CAC', message: `${customer.ltvCacRatio.toFixed(2)}x LTV:CAC — below 3x. Reduce CAC or increase customer value.` })
  } else {
    score += 0
    flags.push({ type: 'danger', metric: 'LTV:CAC', message: `${customer.ltvCacRatio.toFixed(2)}x LTV:CAC — you're losing money on acquisition. Stop scaling until fixed.` })
  }

  // ── Churn Rate (20 pts) ────────────────────────────
  if (customer.churnRate <= 2) {
    score += 20
    flags.push({ type: 'good', metric: 'Churn Rate', message: `${customer.churnRate.toFixed(1)}% monthly churn — excellent retention.` })
  } else if (customer.churnRate <= 5) {
    score += 10
    flags.push({ type: 'warning', metric: 'Churn Rate', message: `${customer.churnRate.toFixed(1)}% monthly churn — acceptable but focus on retention.` })
  } else {
    score += 0
    flags.push({ type: 'danger', metric: 'Churn Rate', message: `${customer.churnRate.toFixed(1)}% monthly churn — critical. You're losing customers faster than you gain them.` })
  }

  // ── Net Margin (20 pts) ────────────────────────────
  if (revenue.netMarginPercent >= 20) {
    score += 20
    flags.push({ type: 'good', metric: 'Net Margin', message: `${revenue.netMarginPercent.toFixed(1)}% net margin — very profitable.` })
  } else if (revenue.netMarginPercent >= 10) {
    score += 12
    flags.push({ type: 'warning', metric: 'Net Margin', message: `${revenue.netMarginPercent.toFixed(1)}% net margin — healthy but aim for 20%+.` })
  } else if (revenue.netMarginPercent >= 0) {
    score += 5
    flags.push({ type: 'warning', metric: 'Net Margin', message: `${revenue.netMarginPercent.toFixed(1)}% net margin — barely profitable. Cut costs or raise prices.` })
  } else {
    score += 0
    flags.push({ type: 'danger', metric: 'Net Margin', message: `${revenue.netMarginPercent.toFixed(1)}% net margin — operating at a loss.` })
  }

  // ── Margin of Safety (10 pts) ──────────────────────
  if (breakEven.marginOfSafety >= 30) {
    score += 10
    flags.push({ type: 'good', metric: 'Margin of Safety', message: `${breakEven.marginOfSafety.toFixed(1)}% above break-even — well cushioned.` })
  } else if (breakEven.marginOfSafety >= 10) {
    score += 5
    flags.push({ type: 'warning', metric: 'Margin of Safety', message: `${breakEven.marginOfSafety.toFixed(1)}% above break-even — thin cushion.` })
  } else {
    score += 0
    flags.push({ type: 'danger', metric: 'Margin of Safety', message: `${breakEven.marginOfSafety.toFixed(1)}% — dangerously close to (or below) break-even.` })
  }

  // ── Grade ──────────────────────────────────────────
  const grade =
    score >= 85 ? 'A' :
    score >= 70 ? 'B' :
    score >= 55 ? 'C' :
    score >= 40 ? 'D' : 'F'

  const summary =
    grade === 'A' ? 'Strong fundamentals. This business is in great shape.' :
    grade === 'B' ? 'Solid business with a few areas to tighten up.' :
    grade === 'C' ? 'Functional but fragile. Several metrics need attention.' :
    grade === 'D' ? 'At risk. Address the flagged issues before scaling.' :
                    'Critical. The business model needs fundamental rethinking.'

  return { score, grade, summary, flags }
}
