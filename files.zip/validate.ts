// ============================================
// src/utils/validate.ts
// Input validation with Zod
// ============================================

import { z } from 'zod'

const positiveNumber = (label: string) =>
  z.number({ required_error: `${label} is required` })
   .nonnegative(`${label} must be 0 or greater`)

const positiveInt = (label: string) =>
  z.number({ required_error: `${label} is required` })
   .int()
   .nonnegative(`${label} must be 0 or greater`)

export const BusinessInputSchema = z.object({
  // Revenue
  monthlyRevenue:            positiveNumber('Monthly Revenue'),
  annualRevenue:             positiveNumber('Annual Revenue').optional(),
  recurringRevenue:          positiveNumber('Recurring Revenue').optional(),

  // Costs
  costOfGoodsSold:           positiveNumber('Cost of Goods Sold'),
  operatingExpenses:         positiveNumber('Operating Expenses'),
  monthlyBurnRate:           positiveNumber('Monthly Burn Rate').optional(),

  // Customers
  totalCustomers:            positiveInt('Total Customers'),
  newCustomersPerMonth:      positiveInt('New Customers Per Month'),
  lostCustomersPerMonth:     positiveInt('Lost Customers Per Month'),
  avgCustomerLifespanMonths: positiveNumber('Avg Customer Lifespan (months)'),

  // Acquisition
  totalMarketingSpend:       positiveNumber('Total Marketing Spend'),
  totalSalesSpend:           positiveNumber('Total Sales Spend'),

  // Pricing
  avgRevenuePerCustomer:     positiveNumber('Avg Revenue Per Customer'),
  avgTransactionValue:       positiveNumber('Avg Transaction Value').optional(),
  transactionsPerCustomerPerMonth: positiveNumber('Transactions Per Customer Per Month').optional(),
})

export type ValidatedInput = z.infer<typeof BusinessInputSchema>

export interface ValidationResult {
  success: boolean
  data?: ValidatedInput
  errors?: Record<string, string>
}

/**
 * Validate raw user input and return typed result
 */
export function validateInput(raw: unknown): ValidationResult {
  const result = BusinessInputSchema.safeParse(raw)

  if (result.success) {
    return { success: true, data: result.data }
  }

  const errors: Record<string, string> = {}
  for (const issue of result.error.issues) {
    const key = issue.path.join('.')
    errors[key] = issue.message
  }

  return { success: false, errors }
}
